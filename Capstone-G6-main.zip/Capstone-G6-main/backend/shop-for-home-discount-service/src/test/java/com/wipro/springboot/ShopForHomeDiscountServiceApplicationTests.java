package com.wipro.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopForHomeDiscountServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
