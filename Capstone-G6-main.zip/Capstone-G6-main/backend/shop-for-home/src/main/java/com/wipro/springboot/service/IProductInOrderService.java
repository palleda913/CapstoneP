package com.wipro.springboot.service;

import com.wipro.springboot.entity.ProductInOrder;
import com.wipro.springboot.entity.User;

public interface IProductInOrderService {

	void update(String itemId, Integer quantity, User user);

	ProductInOrder findOne(String itemId, User user);
}
