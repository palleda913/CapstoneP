package com.wipro.springboot.enums;

public interface CodeEnum {
	Integer getCode();

}
