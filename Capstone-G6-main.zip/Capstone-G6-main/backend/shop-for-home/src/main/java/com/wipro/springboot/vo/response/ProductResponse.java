package com.wipro.springboot.vo.response;

import java.util.List;

import com.wipro.springboot.entity.Product;


public class ProductResponse {

	private List<Product> productList;

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

}
