import {User} from '../models/User'

export class UserListResponse {
    user : User[]

}

