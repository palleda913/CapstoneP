export enum Role {
    Customer = 'ROLE_CUSTOMER',
    Manager = 'ROLE_MANAGER'
}
