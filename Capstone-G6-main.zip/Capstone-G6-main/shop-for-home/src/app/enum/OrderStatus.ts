export enum OrderStatus {
    "New",
    "Finished",
    "Cancelled"
}
