export enum CategoryType {
    "Books", "Coffee Mugs", "Mouse Pads", "Luggage Tags"
}
