/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { OrderByPipe } from './order-by.pipe';

describe('Pipe: OrderBye', () => {
  it('create an instance', () => {
    let pipe = new OrderByPipe();
    expect(pipe).toBeTruthy();
  });
});
