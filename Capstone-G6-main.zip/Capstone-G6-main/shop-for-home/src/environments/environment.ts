// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false
};
export const apiUrl = '//localhost:8081/api';
export const disUrl = '//localhost:8082/api';
export const repoUrl = '//localhost:8083/api';


